<?php
require_once("../resource/config.php");
 ?>
 <?php
require_once("cart.php");
?>
<?php
include TEMPLATE_FRONT.DS."header.php";
 ?>

    <!-- Navigation -->

    <?php
    include TEMPLATE_FRONT.DS."nav.php";
     ?>
     <?php
// $_SESSION['order_total'];
?>

    <!-- Page Content -->
    <div class="container">


<!-- /.row -->

<div class="row">

      <h1>Checkout</h1>
      <h3 class="text-danger text-center">
          <?php
          display_message();
          ?>
      </h3>


<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
  <input type="hidden" name="cmd" value="_xclick">
  <input type="hidden" name="business" value="lwin1@greenhackersonline.com">
    <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
           <th></th>
           <th></th>

          </tr>
        </thead>
        <tbody>
      <?php
            cart();
            ?>
        </tbody>
    </table>
    <input type="image" name="upload"
    src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
    alt="PayPal - The safer, easier way to pay online">
</form>



<!--  ***********CART TOTALS*************-->

<div class="col-xs-4 pull-right ">
<h2>Cart Totals</h2>

<table class="table table-bordered" cellspacing="0">

<tr class="cart-subtotal">
<th>Items:</th>
<td><span class="amount">
    <?php
    echo isset($_SESSION['item_quantity'])?$_SESSION['item_quantity']:$_SESSION['item_quantity']='';
    ?>
</span></td>
</tr>
<tr class="shipping">
<th>Shipping and Handling</th>
<td>Free Shipping</td>
</tr>

<tr class="order-total">
<th>Order Total</th>
<td><strong><span class="amount">
    <?php
    echo isset($_SESSION['order_total'])?$_SESSION['order_total']:$_SESSION['order_total']='';
    ?>
</span></strong> </td>
</tr>


</tbody>

</table>

</div><!-- CART TOTALS-->


 </div><!--Main Content-->


           <?php
    include TEMPLATE_FRONT.DS."footer.php";
     ?>
