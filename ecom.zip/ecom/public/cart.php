<?php
require_once("../resource/config.php");
 ?>
 <?php
if(isset($_GET['add'])){
    //$_SESSION['product_'.$_GET['add']]+=1;
    //redirect('index.php');
    $query=query("SELECT * FROM product where product_id=".escape_string($_GET['add'])."");
    confirm($query);
    while($row=fetch_array($query)){
        if($row['product_quantity'] != $_SESSION['product_'.$_GET['add']]){
            $_SESSION['product_'.$_GET['add']] += 1;
            redirect('checkout.php');
        }else{
            set_message("We Only have {$row['product_title']} {$row['product_quantity']} Available");
            redirect('checkout.php');
        }
    }
}
if(isset($_GET['remove'])){
    $_SESSION['product_'.$_GET['remove']]--;
    if($_SESSION['product_'.$_GET['remove']]<1){
        unset($_SESSION['order_total']);
        unset($_SESSION['item_quantity']);
        redirect('checkout.php');
    }else{
        redirect('checkout.php');
    }
}
if(isset($_GET['delete'])){
    $_SESSION['product_'.$_GET['delete']]=0;
        unset($_SESSION['order_total']);
        unset($_SESSION['item_quantity']);
        redirect('checkout.php');
}
function cart(){
    $total=0;
    $quantity=0;
    $item_name=1;
    $item_number=1;
    $item_amount=1;
    $item_quantity=1;
    foreach($_SESSION as $name=>$value){
        if($value>0){

            if(substr($name,0,8) == 'product_'){
                $length=strlen($name)-8;
                $id=substr($name,8,$length);
                $query=query("SELECT * FROM product where product_id=$id");
    confirm($query);
    while($row=fetch_array($query)){
        $sub_total=$row['product_price']*$value;

        $product=<<<DELIMETER
            <tr>
                <td>{$row['product_title']}</td>
                <td>{$row['product_price']}</td>
                <td>{$value}</td>
                <td>{$sub_total}</td>
                <td>
                    <a href="cart.php?remove={$row['product_id']}" class="btn btn-warning btn-sm"><span class="glyphicon glyphicon-minus"></span></a>
                    <a href="cart.php?add={$row['product_id']}" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-plus"></span></a>
                    <a href="cart.php?delete={$row['product_id']}" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-remove"></span></a></td>
            </tr>
            <input type="hidden" name="item_name_{$item_name}" value="{$row['product_title']}">
            <input type="hidden" name="item_number_{$item_number}" value="{$row['product_id']}">
            <input type="hidden" name="amount_{$item_amount}" value="{$sub_total}">
            <input type="hidden" name="quantity_{$item_quantity}" value="{$value}">
DELIMETER;
        echo $product;
        $item_quantity++;
        $item_name++;
        $item_number++;
        $item_amount++;
      }
        $_SESSION['order_total']=$total+=$sub_total;
        $_SESSION['item_quantity']=$quantity+=$value;

            }
        }
    }

}
?>
