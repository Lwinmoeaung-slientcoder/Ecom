<?php 
require_once("../resource/config.php");
 ?>
<?php 
include TEMPLATE_FRONT.DS."header.php";
 ?>

    <!-- Navigation -->
    <?php 
    include TEMPLATE_FRONT.DS."nav.php";
     ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-3">
                <?php 
                include TEMPLATE_FRONT.DS."sidebar.php";
                 ?>
            </div>

            <div class="col-md-9">

                <?php 
                include TEMPLATE_FRONT.DS."slideshow.php";
                 ?>

                <div class="row">
<!--
                <h1>
                    <?php
                    echo $_SESSION['product_1'];
                    ?>
                </h1>
-->
                    <?php
                    get_product();
                    ?>

                    
                </div>

            </div>

        </div>

    </div>
    <!-- /.container -->

    <?php 
    include TEMPLATE_FRONT.DS."footer.php";
     ?>