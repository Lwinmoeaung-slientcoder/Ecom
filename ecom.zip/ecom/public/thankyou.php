<?php
require_once("../resource/config.php");
 ?>
 <?php
require_once("cart.php");
?>
<?php
include TEMPLATE_FRONT.DS."header.php";
 ?>
 <!-- <?php
//session_destory();
 ?> -->
    <!-- Page Content -->
    <div class="container">
<h1 class="text-center">Thank You </h1>
<div class="text-center">
<a href="index.php" class="btn btn-primary">Go To homepage</a>
<a href="shop.php" class="btn btn-success">Go To Shop</a>
</div>
<!-- /.row -->

 </div><!--Main Content-->


           <?php
    include TEMPLATE_FRONT.DS."footer.php";
     ?>
