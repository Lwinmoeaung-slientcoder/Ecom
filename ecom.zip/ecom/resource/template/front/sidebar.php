<p class="lead">Shop Name</p>
    <div class="list-group">
    <?php
   get_category();  
    ?>
        
    </div>