<?php
function set_message($msg){
    if(!empty($msg)){
        $_SESSION['message']=$msg;
    }else{
        $msg='';
    }
}
function display_message(){
    if(isset($_SESSION['message'])){
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
}
function redirect($location){
	header("Location:$location");
}
function escape_string($string){
	global $connection;
	return mysqli_real_escape_string($connection,$string);
}
function query($query){
	global $connection;
	return mysqli_query($connection,$query);
}
function confirm($result){
	if(!$result){
		die('Query Failed!'.mysqli_error($connection));
	}
}
function fetch_array($result){
	return mysqli_fetch_array($result);
}
function get_product(){
	$result=query("SELECT * FROM product");
	confirm($result);
	while($row=fetch_array($result)){
    $product=<<<DELIMETER
    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <img src="{$row['product_image']}" alt="">
                            <div class="caption">
                                <h4 class="pull-right">$ {$row['product_price']}</h4>
                                <h4><a href="item.php?id={$row['product_id']}">{$row['product_title']}</a>
                                </h4>
                                <p>See more snippets like this online store item at <a target="_blank" href="http://www.bootsnipp.com">Bootsnipp - http://bootsnipp.com</a>.</p>
                            </div>
                            <a class="btn btn-primary" target="_blank" href="cart.php?add={$row['product_id']}">Add to Cart</a>

                        </div>
                    </div>
DELIMETER;
        echo $product;
	}

}

function get_category(){
    $result=query("SELECT * FROM category");
    confirm($result);
    while($row=fetch_array($result)){
echo "<a href='category.php?id={$row['cat_id']}' class='list-group-item'>{$row['cat_title']}</a>";


    }
}

function get_product_in_category(){
	$result=query("SELECT * FROM product WHERE product_cat_id=".escape_string($_GET['id'])."");
	confirm($result);
	while($row=fetch_array($result)){
    $product=<<<DELIMETER
    <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="{$row['product_image']}" alt="">
                    <div class="caption">
                        <h3>Feature Label</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                            <a href="#" class="btn btn-primary">Buy Now!</a> <a href="item.php?id={$row['product_id']}" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
        </div>
DELIMETER;
        echo $product;
	}

}

function get_product_in_shop(){
	$result=query("SELECT * FROM product");
	confirm($result);
	while($row=fetch_array($result)){
    $product=<<<DELIMETER
    <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="{$row['product_image']}" alt="">
                    <div class="caption">
                        <h3>Feature Label</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                            <a href="#" class="btn btn-primary">Buy Now!</a> <a href="item.php?id={$row['product_id']}" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
        </div>
DELIMETER;
        echo $product;
	}

}

function login_user(){
    if(isset($_POST['submit'])){
        $username=escape_string($_POST['username']);
        $password=escape_string($_POST['password']);
        $query=query("SELECT * FROM user where username='$username' AND password='$password'");
        confirm($query);
        if(mysqli_num_rows($query)==0){
            set_message("Something is Wrong!Please Check Your User Name or Password!");
            redirect('login.php');
        }else{
            set_message("Welcome Admin $username");
            redirect('admin');
        }
    }
}

function contact_message(){
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $email_from=$_POST['email'];
        $subject=$_POST['subject'];
        $message=$_POST['message'];

        $to="chitthat29@gmail.com";
        $header="From $email_from";
        $result=mail($to,$subject,$message,$header);

        if(!$result){
            set_message('Message Fail!');
        }else{
            set_message('Message Success!');
        }
    }
}
?>
